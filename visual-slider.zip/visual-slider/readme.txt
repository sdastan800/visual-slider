﻿=== Visual Slider ===
Contributors: Dastan
Tags:  Drag & Drop Slider anything at any in Visual Composer
Requires PHP: 7.4.0
Requires at least: 5.9
Tested up to: 5.9
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 

== Description ==
Drag & Drop Slider anything at any in Visual Composer


== Installation ==

1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Pages > Add New
4. Press the 'Edit with Elementor' button.
5. Now you can drag and drop widgets from the left panel onto the content area, as well as add new sections and columns that make up the page structure.


== Changelog ==
 

= 1.0 =

* First Version